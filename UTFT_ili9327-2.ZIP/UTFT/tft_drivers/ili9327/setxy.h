case ILI9327:
	LCD_Write_COM_DATA(0x2a,x1);
  	//LCD_Write_DATA(0x00,x1>>8);
  	//LCD_Write_DATA(0x00,x1);
  	LCD_Write_DATA(x2>>8,x2);
  	//LCD_Write_DATA(0x00);
  	LCD_Write_COM_DATA(0x2b,y1);
  	//LCD_Write_DATA(0x00,y1>>8);
  	//LCD_Write_DATA(0x00,y1);
  	//LCD_Write_DATA(0x00,0x00);
  	LCD_Write_DATA(y2>>8,y2);
  	LCD_Write_COM(0x2c); 							 
	break;
